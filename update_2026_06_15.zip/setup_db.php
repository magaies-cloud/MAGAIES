<?php
require "api/db.php";

$tables = [
    'users', 'customers', 'suppliers', 'items', 'inventory',
    'sales_invoices', 'purchase_invoices', 'receipts', 'payments', 'journal_vouchers', 'settings',
    'warehouses', 'banks', 'categories', 'roles', 'tenants'
];

$pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");
foreach ($tables as $table) {
    $pdo->exec("DROP TABLE IF EXISTS $table");
}
$pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");

include "schema.php";
echo "Database reset and schema applied.";
